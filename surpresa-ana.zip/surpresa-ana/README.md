# 🌟 Surpresa para Ana

Um projeto interativo em HTML feito para surpreender a Ana 💫

## 🚀 Como funciona
- É um pequeno quebra-cabeça: a Ana deve clicar nas peças na ordem certa.
- Quando acerta, aparece uma mensagem especial ✨

## 💻 Como rodar
1. Baixe ou clone este repositório:
   ```bash
   git clone https://github.com/seu-usuario/surpresa-ana.git
   ```
2. Abra o arquivo `ANA.html` no navegador.

## 🌍 Publicar no GitHub Pages
1. Vá em **Settings** → **Pages**.
2. Selecione a branch `main` e salve.
3. O link ficará disponível em:
   ```
   https://seu-usuario.github.io/surpresa-ana/
   ```

---
Feito com ❤️ para a Ana.
